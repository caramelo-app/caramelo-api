module.exports = {
    TYPES: {
        YEAR: "year",
        MONTH: "month",
        DAY: "day"
    }
}