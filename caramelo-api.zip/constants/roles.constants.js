module.exports = {
    USER_ROLES: {
        ADMIN: "admin",
        CLIENT: "client",
        CONSUMER: "consumer"
    }
}